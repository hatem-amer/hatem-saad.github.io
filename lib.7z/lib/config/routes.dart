class Routes {
  static String splash = '/';
  static String signIn = '/signIn';
  static String home = '/home';
  static String barScan = '/barScan';
  static String qrVerified = '/qrVerified';
  static String forgotPassword = '/forgotPassword';
}
