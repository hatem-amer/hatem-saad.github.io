// images assets in app

// taps
const String tap1 = "assets/images/taps/floor.svg";
const String tap2 = "assets/images/taps/list.svg";
const String tap3 = "assets/images/taps/grid.svg";
const String tap4 = "assets/images/taps/members.svg";
const String tap6 = "assets/images/taps/reports.svg";

// logo
const String splash = "assets/images/logo/splash.svg";
const String logeIcon = "assets/images/logo/logeIcon.svg";

const String check = "assets/images/other/check.svg";
const String table = "assets/images/other/table.svg";
const String qr = "assets/images/other/qr.svg";
const String doubleTable = "assets/images/other/2Tables.svg";
const String gate = "assets/images/other/gate.svg";
const String tableIcon = "assets/images/other/tableIcon.svg";
const String clock = "assets/images/other/clock.svg";
const String people = "assets/images/other/people.svg";
const String prize = "assets/images/other/prize.svg";
const String mobile = "assets/images/other/mobile.svg";
const String calendar = "assets/images/other/calendar.svg";
const String notification = "assets/images/other/notification.svg";
const String qrIcon = "assets/images/other/qrIcon.svg";
